<!DOCTYPE html>
<?php
session_start();
?>
<html>
<head>
    <title>users page</title>
	<link rel="stylesheet" href="1.css" type="text/css">
		    <link rel="stylesheet" type="text/css" href="css/stylesheet.css" />



</head>
	<body>
<?php	

 include ('header.php');
?> 
<div id="bottom">
<br>
<br><br>
<h1>PLEASE CONTACT ADMINISTRATOR FOR NEW PASSWORD AT admin@exam.com</h1>
</div>
<hr>


</div>
<hr>
</div>
</div>

</form>
</body>
</html>
