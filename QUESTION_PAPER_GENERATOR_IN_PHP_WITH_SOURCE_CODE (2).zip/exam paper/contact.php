<!DOCTYPE html>
<?php
session_start();
?>
<html>
<head>
    <title>Sign up page</title> 
 
</head>
<body>
<?php
 include ('header.php');?>

<div id="bottom">
<hr>
<h1><u>CONTACT US HERE!</u></h1>
<hr>
<h2><b>For all queries please contact us at the below addresses:</b></h2>
<h4>
	<p>This is the contact us page</p>
</div>
</body>
</html>
