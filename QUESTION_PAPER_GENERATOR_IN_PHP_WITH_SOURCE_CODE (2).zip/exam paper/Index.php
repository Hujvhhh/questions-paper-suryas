﻿<!DOCTYPE html>
<?php 
session_start();
?>
<html>
<head>
    <title>Question paper generator</title>
    <link type="text/css" rel="stylesheet" href="StyleSheet1.css" />
</head>
<body>

<?php
 include ('header.php');?>
</div>  
 <div id="bottom">
<br>
<br>
<div id="boxes">
<marquee  behavior="alternate" width="100%" scrolldelay="200" >
<h3>UNIQUE FEATURES</h3>
</marquee>
<ol>
<li type="square">
A Customised solution
</li>
<li type="square">
Generates a set of various types of questions.
</li>
<li type="square">
English and Mathematics
</li>
<li type="square">
Questions are based on learning objectives
</li>
<li type="square">
Can add user defined questions.
</li>

</ol>

</div>
<div id="boxes">
<marquee  behavior="alternate" width="100%" scrolldelay="200" >

<h3>NEWS & EVENTS</h3>
</marquee>
<ol>
<li type="square">
Date : 27-Mar-2014 
Qpgen.Com - Question Paper Generator website launched.
</li>
<li type="square">
Date : 5-Apr-2014 
Complimentary membership for ABC customer schools.
</li>
</ol>
</div>

<div id="boxes">
<marquee  behavior="alternate" width="100%" scrolldelay="200" >

<h3>FEEDBACK CORNER</h3>
</marquee>
<u>Teachers Feedback</u>
<ol>
<li type="square">
A brilliant effort!! Would say congratulation JILIT! 
Contains a vivid array of questions and keeps all the testing parameters in view while generating the question paper.
Hats off!  
</li>
<li type="square">
Now we will have lots of time to utilize for other constructive work.</li>
<li type="square">
It is something that we always required.</li>

</ol>
</div>

<div id="boxes1">
                                    
<img height="200" width="1300" src="images.jpg"/>


</div>


 </div>

<div id="footer">
Content goes here</div>

 <br/>
</body>
</html>
