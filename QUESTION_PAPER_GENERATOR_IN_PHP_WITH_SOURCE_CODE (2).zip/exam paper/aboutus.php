<!DOCTYPE html>
<?php
session_start();
?>
<html>
<head>
    <title>Sign up page</title>
</head>
<body>
<?php
 include ('header.php');?>

<div id="bottom">
<hr>
<h1><u>ABOUT US!</u></h1>
<hr>
<p>The Right Click Solutions is well diversified infrastructural industrial conglomerate in India.
 Over the decades it has maintained its salience with leadership in its chosen line of businesses - Engineering and Construction, Cement, Private Hydropower, Hospitality, Real Estate Development, Expressways and Highways and Education.
</p>
<p>
Right Click Solutions is an ISO 9001-2008 certified company and is an Infotech arm of the diversified Right solutions Group. The address of registered office of RCS is:
Head office : 403,Arun soc ,Near Om Super Market
</p>
<p>
As a leading player in the education content development segment, RCS had pioneered - "Bhartiyavidya" -India's first digital-classroom-teaching aid that is facilitating the teaching process in over 650 schools across the country and overseas.
</p>
<p>
Bhartiyavidya is a content rich, high quality multimedia based pioneering effort in the area of computer aided classroom teaching that helps the teacher explain difficult concepts in subjects like science, mathematics and social sciences through the aid of visual capsules inside the classroom. Bhartiyavidya solution encompasses a digital library of over 3500 capsules of about 3 minutes duration.

 </p>

</div>
</body>
</html>
